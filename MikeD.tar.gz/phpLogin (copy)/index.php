<?php
    require "header.php";
?>

    <main>
      <p>You are logged out!</p>  
      <p>You are logged in!</p>
    </main>

<?php
    require "footer.php";
?>